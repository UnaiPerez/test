// const div = document.createElement('div')
// div.innerText = 'Texto creado desde el script'
// document.body.appendChild(div)