async function init(){
  const form = document.getElementById("settingsForm")
  const input = document.getElementById("apiKey")
 
  const key = "apiKey"
   // Cargar valor guardado al abrir la página
  const result = await chrome.storage.local.get([key]);
  if (result[key]) {
    input.value = result[key];
  }
 
  document.getElementById("aa").addEventListener("click", async (e) => {
    e.preventDefault()
 
    const valor = input.value;
 
    await chrome.storage.local.set({
        [key]:valor
    })
 
  })
 
}

init()
