
/*
const styleKey = 'USER_STYLE'

const blob2base64 = async (blob, mimeType) => {
  const buf = await blob.arrayBuffer()
    const bytes = new Uint8Array(buf)
    let binary = ''
    for(let i = 0; i<bytes.length;i++){
      binary+= String.fromCharCode(bytes[i])
    }

    const base64 = btoa(binary)
    return `data:${mimeType};base64,${base64}`
};

const esperar = (ms) => {

  return new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve('Tiempo cumplido')
      }, ms)
    })
}

const getAvatar = async (userId, sendResponse) => {

  const opts = await chrome.storage.local.get([styleKey])
  const style = opts[styleKey] == null ? 'pixel-art' : opts[styleKey]



  const key = `AVATAR_${style}_${userId}`
  const ret = await chrome.storage.local.get([key])
  if(ret[key] != null){
    sendResponse({ok: true, img: ret[key]}) 
    return 
  }

  const url = `https://api.dicebear.com/9.x/${style}/png?seed=${userId}`

  const response = await fetch(url)
  if(!response.ok) throw new Error('ha habido un problema con la api del dicebear')
  const avatar = await response.blob()
  const imgBase64 = await blob2base64(avatar, 'image/png')
  sendResponse({ok: true, img: imgBase64})
  const obj = {}
  obj[key] = imgBase64
  chrome.storage.local.set(obj)
}

let ultimoAlumno = Promise.resolve()

const addToQueue = (studentId, sendResponse) => {
  const p = ultimoAlumno.then( async () => {
    await esperar(2000)
    getAvatar(studentId, sendResponse)
  })
  ultimoAlumno = p
  return p
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if(msg.action !== 'GET_AVATAR') return
  if( msg.studentId == null ) return
  addToQueue(msg.studentId, sendResponse)

  return true
})
*/

chrome.action.onClicked.addListener( async (tab) => {

  const url = tab.url

  console.log("La extension ha sido clickada")
  console.log("URL actual: ", url)

  const keyData = await chrome.storage.local.get("apiKey")
  const apiKey = keyData.apiKey

  console.log("API KEY recuperada:", apiKey)

  if(!apiKey){
    console.log("No hay API key guardada")
    return
  }

  if(!esPDFEgela(url)){
    console.log("No es un PDF de egela !!!!")
    return;
  }

  console.log("Esto es un pdf de egela")

  await comprobar(url)

})


// Funcion para ver si es un PDF de egela
function esPDFEgela(url){

  if(!url) return false

  return url.includes('egela.ehu.eus') && url.endsWith(".pdf")

}


// Funcion para comprobar si es la primera q se intenta usar el pdf, e ir añadiendo diferentes funciones
async function comprobar(url){
  const data = await chrome.storage.local.get("pdfs")
  console.log(data)

  const guardados = data.pdfs || {}
  console.log(guardados)

  if(guardados[url]){

    console.log("Ya esta registrado")
    console.log("SourceId: ", guardados[url])

    const keyData = await chrome.storage.local.get("apiKey")
    const apiKey = keyData.apiKey

    const contenido = await preguntas(guardados[url], apiKey)
    console.log("Preguntas generadas: ", contenido)

  } else{

     console.log("Primera vez del pdf")

    const keyData = await chrome.storage.local.get("apiKey")
    const apiKey = keyData.apiKey

    const blob = await descargarPDF(url)
    const id = await subirPDF(blob,apiKey)

    guardados[url] = id
    await chrome.storage.local.set({ pdfs: guardados })

    console.log("PDF registrado: ", id)

  }

}


// Funcion para descargar el pdf
async function descargarPDF(url){
  console.log('Intentando la descarga...')

  const response = await fetch(url)

  if(!response.ok){
    console.log("Ha habido un error durante la descarga del PDF.")
  }

  const blob = await response.blob()
  console.log("PDF descargado")
  console.log("Tipo: ", blob.type)
  console.log("Tamaño: ", blob.size)

  return blob
}


// Funcion para subir el PDF a ChatPDF
async function subirPDF(blob, apiKey) {
  console.log("Intento de subir el pdf...")

  const formData = new FormData()
  formData.append("file",blob,"documento.pdf")

  const response = await fetch("https://api.chatpdf.com/v1/sources/add-file", {
    method: "POST",
    headers: {
      "x-api-key": apiKey
    },
    body: formData
  })

  if(!response.ok)
    throw new Error("Error al subir el pdf")

  console.log(response)
  const data = await response.json()
  console.log("Respuesta de chatPDF: ", data)
  return data.sourceId
}

// Funcion para generar las preguntas en ChatPDF
async function preguntas(id, apiKey){

  console.log("Generando las preguntas...")

  const prompt = `
    Genera exactamente 8 preguntas tipo test basadas exclusivamente en el contenido de este PDF.

    Devuelve solo y unicamente un JSON valido con la siguiente estructura:

    [
      {
        "pregunta": "Texto de la pregunta",
        "opciones": ["Opcion A", "Opcion B", "Opcion C", "Opcion D"],
        "correcta": "Texto exacto de la opcion correcta"
      }
    ]

    Cada pregunta debe de tener 4 respuestas posibles solo.
    De esas 4 solo una opcion correcta unicamente.
    No incluyas ningun tipo de texto adicional fuera del JSON a devolver.
    Devuelve solo el JSON.
  `

  const response = await fetch("https://api.chatpdf.com/v1/chats/message", {
    method: "POST", 
    headers: {
      "x-api-key": apiKey,
      "Content-type": "application/json"
    },
    body: JSON.stringify({
      sourceId: id,
      messages: [
        {
          role: "user",
          content: prompt
        }
      ]
    })
  })

  if(!response.ok)
    throw new Error("Error en la generacion de las preguntas")

  const data = await response.json()
  console.log("Respuesta enviada por ChatPDF: ", data)
  return data.content
}